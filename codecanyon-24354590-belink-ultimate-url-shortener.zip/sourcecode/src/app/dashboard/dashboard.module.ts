import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {DashboardHostComponent} from './dashboard-host/dashboard-host.component';
import {UiModule} from '@common/core/ui/ui.module';
import {DashboardRoutingModule} from './dashboard-routing.module';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatDialogModule} from '@angular/material/dialog';
import {MatSidenavModule} from '@angular/material/sidenav';
import {RouterModule} from '@angular/router';
import {LinkOptionsFormComponent} from './link/link-options-form/link-options-form.component';
import {ChipInputModule} from '@common/core/ui/chip-input/chip-input.module';
import {LinkIndexComponent} from './link/link-index/link-index.component';
import {DataTableModule} from '@common/shared/data-table/data-table.module';
import {CrupdateLinkModalComponent} from './link/crupdate-link-modal/crupdate-link-modal.component';
import {LinkShowComponent} from './link/link-show/link-show.component';
import {ChartsModule} from '@common/shared/charts/charts.module';
import {LinkGroupIndexComponent} from './link-group/link-group-index/link-group-index.component';
import {DashboardHomeComponent} from './dashboard-home/dashboard-home.component';
import {ClickChartsComponent} from './click-charts/click-charts.component';
import {SharedModule} from '../shared/shared.module';
import {CrupdateLinkGroupModalComponent} from './link-group/crupdate-link-group-modal/crupdate-link-group-modal.component';
import {LinkGroupShowComponent} from './link-group/link-group-show/link-group-show.component';
import {AttachLinkModalComponent} from './link-group/attach-link-modal/attach-link-modal.component';
import {CustomDomainModule} from '@common/custom-domain/custom-domain.module';
import {LinkOverlayIndexComponent} from './link-overlay/link-overlay-index/link-overlay-index.component';
import {CrupdateLinkOverlayModalComponent} from './link-overlay/crupdate-link-overlay-modal/crupdate-link-overlay-modal.component';
import {
    MatMenuModule,
    MatProgressBarModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatTabsModule
} from '@angular/material';
import {ColorPickerModule} from '@common/core/ui/color-picker/color-picker.module';
import {CustomPagesManagerModule} from '@common/core/pages/manager/custom-pages-manager.module';
import {LinkTypeMenuComponent} from './link/link-type-menu/link-type-menu.component';
import {DatetimeInputModule} from '@common/core/ui/datetime-input/datetime-input.module';
import {LINK_PAGE_TYPE} from './link/types';
import {LinkUsageInfoComponent} from './dashboard-host/link-usage-info/link-usage-info.component';
import {UpgradePanelComponent} from './dashboard-host/upgrade-panel/upgrade-panel.component';
import {TrackingPixelIndexComponent} from './pixels/tracking-pixel-index/tracking-pixel-index.component';
import {CrupdateTrackingPixelModalComponent} from './pixels/crupdate-tracking-pixel-modal/crupdate-tracking-pixel-modal.component';

@NgModule({
    declarations: [
        DashboardHostComponent,
        DashboardHomeComponent,
        LinkOptionsFormComponent,
        LinkIndexComponent,
        CrupdateLinkModalComponent,
        LinkShowComponent,
        ClickChartsComponent,
        LinkGroupIndexComponent,
        CrupdateLinkGroupModalComponent,
        LinkGroupShowComponent,
        AttachLinkModalComponent,
        LinkOverlayIndexComponent,
        CrupdateLinkOverlayModalComponent,
        LinkTypeMenuComponent,
        LinkUsageInfoComponent,
        UpgradePanelComponent,
        TrackingPixelIndexComponent,
        CrupdateTrackingPixelModalComponent,
    ],
    imports: [
        CommonModule,
        RouterModule,
        DashboardRoutingModule,

        UiModule,
        SharedModule,
        ChartsModule,
        DataTableModule,
        CustomDomainModule,
        ChipInputModule,
        ColorPickerModule,
        DatetimeInputModule,
        CustomPagesManagerModule.forRoot({
            resourceName: 'link pages',
            type: LINK_PAGE_TYPE,
            showSlug: false,
        }),

        MatSidenavModule,
        MatDialogModule,
        MatButtonToggleModule,
        MatTabsModule,
        MatMenuModule,
        MatProgressBarModule,
        MatSelectModule,
        MatSlideToggleModule,
    ],
    exports: [
        ClickChartsComponent,
    ],
    entryComponents: [
        CrupdateLinkModalComponent,
        CrupdateLinkGroupModalComponent,
        AttachLinkModalComponent,
        CrupdateLinkOverlayModalComponent,
        LinkUsageInfoComponent,
        CrupdateTrackingPixelModalComponent,
    ],
})
export class DashboardModule {
}
