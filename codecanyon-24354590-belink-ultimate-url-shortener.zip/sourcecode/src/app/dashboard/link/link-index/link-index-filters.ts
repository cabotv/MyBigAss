import {DataTableFilters} from '@common/shared/data-table/filter-panel/data-table-filters';

export const LINK_INDEX_FILTERS: DataTableFilters = [
    {
        name: 'status',
        column: 'disabled',
        options: [
            {name: 'all'},
            {name: 'enabled', value: false},
            {name: 'disabled', value: true}
        ]
    },
    {
        name: 'password',
        column: 'password',
        options: [
            {name: 'all'},
            {name: 'with_password', value: true},
            {name: 'without_password', value: false}
        ]
    },
    {
        name: 'expiration',
        column: 'expires_at',
        options: [
            {name: 'all'},
            {name: 'with_expiration_date', value: true},
            {name: 'without_expiration_date', value: false}
        ]
    },
    {
        name: 'type',
        column: 'type',
        options: [
            {name: 'all'},
            {name: 'direct'},
            {name: 'overlay'},
            {name: 'frame'},
            {name: 'custom_page'},
        ]
    },
    {
        name: 'user',
        column: 'user_id',
        type: 'user-select',
    },
];
