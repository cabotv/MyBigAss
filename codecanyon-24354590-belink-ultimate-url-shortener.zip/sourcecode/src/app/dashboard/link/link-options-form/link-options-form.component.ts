import {ChangeDetectionStrategy, Component, Input, OnChanges, SimpleChanges} from '@angular/core';
import {LinkForm} from '../../../shared/link/link.form';
import {SelectOptionLists} from '@common/core/services/value-lists.service';
import {Settings} from '@common/core/config/settings.service';
import {ucFirst} from '@common/core/utils/uc-first';
import {BehaviorSubject} from 'rxjs';

@Component({
    selector: 'link-options-form',
    templateUrl: './link-options-form.component.html',
    styleUrls: ['./link-options-form.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class LinkOptionsFormComponent implements OnChanges {
    @Input() linkOptions: SelectOptionLists;
    private defaultHost$ = new BehaviorSubject<string>(null);

    constructor(
        public linkForm: LinkForm,
        private settings: Settings,
    ) {}

    public ngOnChanges(changes: SimpleChanges) {
        if (changes.linkOptions.currentValue) {
            const defaultHost = this.settings.get('custom_domains.default_host');
            if (defaultHost) {
                this.defaultHost$.next(this.linkOptions.domains.find(d => d.host === defaultHost).host);
            } else {
                const baseUrl = this.settings.getBaseUrl()
                    .replace(/\/$/, '')
                    .replace(/(^\w+:|^)\/\//, '');
                this.defaultHost$.next(baseUrl);
            }
        }
    }

    public capitalize(string: string): string {
        return ucFirst(string);
    }
}
