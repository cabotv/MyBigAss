import {ChangeDetectionStrategy, Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {BehaviorSubject, ReplaySubject} from 'rxjs';
import {Link} from '../../../shared/link/link';
import {LinkForm} from '../../../shared/link/link.form';
import {LinkService} from '../../../shared/link/link.service';
import {Toast} from '@common/core/ui/toast.service';
import {Messages} from '../../../messages.enum';
import {LinkGroup} from '../../../shared/link/link-group';
import {animate, state, style, transition, trigger} from '@angular/animations';
import {ValueLists} from '@common/core/services/value-lists.service';
import {CurrentUser} from '@common/auth/current-user';
import {LINK_PAGE_TYPE, LinkOptionsList} from '../types';
import {Settings} from '@common/core/config/settings.service';
import {finalize} from 'rxjs/operators';
import {MatSlideToggleChange} from '@angular/material';

interface CrupdateLinkModalData {
    link: Link;
    group?: LinkGroup;
}

@Component({
    selector: 'crupdate-link-modal',
    templateUrl: './crupdate-link-modal.component.html',
    styleUrls: ['./crupdate-link-modal.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    animations: [
        trigger('bodyExpansion', [
            state('false', style({height: '0px', visibility: 'hidden'})),
            state('true', style({height: '*', visibility: 'visible'})),
            transition('true <=> false',
                animate('225ms cubic-bezier(0.4,0.0,0.2,1)')),
        ])
    ],
    providers: [LinkForm],
})
export class CrupdateLinkModalComponent implements OnInit {
    public loading$ = new BehaviorSubject(false);
    public updating$ = new BehaviorSubject(false);
    public optionsVisible$ = new BehaviorSubject(false);
    public linkOptions$ = new BehaviorSubject<LinkOptionsList>(null);
    public multiple$ = new ReplaySubject(1);

    constructor(
        private dialogRef: MatDialogRef<CrupdateLinkModalComponent>,
        @Inject(MAT_DIALOG_DATA) public data: CrupdateLinkModalData,
        public linkForm: LinkForm,
        private links: LinkService,
        private toast: Toast,
        private valueLists: ValueLists,
        private currentUser: CurrentUser,
        public settings: Settings,
    ) {
        if (data.link) {
            this.updating$.next(true);
            this.linkForm.patchValue(data.link);
        }
    }

    ngOnInit() {
        this.valueLists.get(['countries', 'domains', 'pages', 'overlays', 'pixels'], {
            userId: this.currentUser.get('id'),
            pageType: LINK_PAGE_TYPE
        }).subscribe(response => {
            this.linkOptions$.next(response);
        });

        this.multiple$.subscribe(() => {
            this.linkForm.group.patchValue({
                long_url: '',
                multiple_urls: '',
                alias: '',
            });
        });
    }

    public confirm() {
        this.loading$.next(true);
        const payload = this.getPayload();
        const request = this.updating$.value ?
            this.links.update(this.data.link.id, payload) :
            this.links.create(payload);

        request.pipe(finalize(() => this.loading$.next(false)))
            .subscribe(response => {
                if (payload.multiple_urls) {
                    this.toast.open(Messages.MULTIPLE_LINKS_CREATE_SUCCESS);
                    this.close((response as {links: Link[]}).links);
                } else {
                    this.toast.open(this.updating$.value ? Messages.LINK_UPDATE_SUCCESS : Messages.LINK_CREATE_SUCCESS);
                    this.close((response as {link: Link}).link);
                }
            }, err => this.linkForm.setErrors(err.messages));
    }

    public close(data?: Link|Link[]) {
        this.dialogRef.close(data);
    }

    public toggleOptions() {
        this.optionsVisible$.next(!this.optionsVisible$.value);
    }

    public typeViewName() {
        const type = this.linkForm.group.get('type').value;
        return type.split(':')[0];
    }

    private getPayload() {
        const payload = this.linkForm.value();
        if (this.data.group) {
            payload.group_id = this.data.group.id;
        }
        return payload;
    }

    public toggleMultiple(e: MatSlideToggleChange) {
        this.multiple$.next(e.checked);
        this.optionsVisible$.next(false);
    }
}
