import {Component, ChangeDetectionStrategy, Inject} from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Toast} from '@common/core/ui/toast.service';
import {Messages} from '../../../messages.enum';
import {LinkGroup} from '../../../shared/link/link-group';
import {LinkGroupService} from '../../../shared/link/link-group.service';
import {FormControl, FormGroup} from '@angular/forms';

interface CrupdateLinkGroupModalData {
    group: LinkGroup;
}

@Component({
    selector: 'crupdate-link-group-modal',
    templateUrl: './crupdate-link-group-modal.component.html',
    styleUrls: ['./crupdate-link-group-modal.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class CrupdateLinkGroupModalComponent {
    public loading$ = new BehaviorSubject(false);
    public updating$ = new BehaviorSubject(false);
    public errors$ = new BehaviorSubject<{name?: string}>({});
    public form = new FormGroup({
        name: new FormControl(),
    });

    constructor(
        private dialogRef: MatDialogRef<CrupdateLinkGroupModalComponent>,
        @Inject(MAT_DIALOG_DATA) public data: CrupdateLinkGroupModalData,
        private linkGroup: LinkGroupService,
        private toast: Toast,
    ) {
        this.updating$.next(!!data.group);
        if (data.group) {
            this.form.patchValue(data.group);
        }
    }

    public confirm() {
        const request = this.updating$.value ?
            this.linkGroup.update(this.data.group.id, this.form.value) :
            this.linkGroup.create(this.form.value);

        request.subscribe(response => {
            this.toast.open(this.updating$.value ? Messages.LINK_GROUP_UPDATE_SUCCESS : Messages.LINK_GROUP_CREATE_SUCCESS);
            this.close(response.group);
        }, err => this.errors$.next(err.messages));
    }

    public close(group?: LinkGroup) {
        this.dialogRef.close(group);
    }
}
