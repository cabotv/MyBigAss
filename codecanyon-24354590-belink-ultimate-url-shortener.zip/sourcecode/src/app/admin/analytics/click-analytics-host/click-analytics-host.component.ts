import {ChangeDetectionStrategy, Component} from '@angular/core';
import {AnalyticsService} from '@common/admin/analytics/analytics.service';

@Component({
    selector: 'click-analytics-host',
    templateUrl: './click-analytics-host.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ClickAnalyticsHostComponent {
    constructor(public analytics: AnalyticsService) {}
}
