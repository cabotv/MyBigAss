import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {AppHttpClient} from '@common/core/http/app-http-client.service';

export interface LinkUsage {
    links: {
        used: number,
        total: number | null,
    };
    clicks: {
        used: number,
        total: number | null,
    };
    link_overlays: {
        used: number,
        total: number | null,
    };
    custom_pages: {
        used: number,
        total: number | null,
    };
    custom_domains: {
        used: number,
        total: number | null,
    };
    link_groups: {
        used: number,
        total: number | null,
    };
    tracking_pixels: {
        used: number,
        total: number | null,
    };
}

@Injectable({
    providedIn: 'root'
})
export class LinkUsageService {
    public usage$ = new BehaviorSubject<LinkUsage>(null);

    constructor(private http: AppHttpClient) {}

    public reload() {
        this.http.get(`link/usage`).subscribe(response => {
            this.usage$.next(response.usage);
        });
    }
}
