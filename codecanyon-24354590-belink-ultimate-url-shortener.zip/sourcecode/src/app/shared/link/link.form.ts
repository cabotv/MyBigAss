import {FormArray, FormBuilder, FormGroup} from '@angular/forms';
import {Injectable} from '@angular/core';
import {Link} from './link';
import {BehaviorSubject} from 'rxjs';
import {CrupdateLinkPayload} from './link.service';
import {Settings} from '@common/core/config/settings.service';

interface LinkErrors extends Partial<Link> {
    multiple_urls?: string;
}

@Injectable({
    providedIn: 'root'
})
export class LinkForm {
    public group: FormGroup;
    public errors$ = new BehaviorSubject<LinkErrors>({});

    constructor(
        private fb: FormBuilder,
        private settings: Settings,
    ) {
        this.build();
    }

    public addRule(type: 'geo'|'device') {
        const arr = type === 'geo' ? this.geoRules() : this.deviceRules();
        arr.push(this.newRuleGroup(type));
    }

    public removeRule(type: 'geo'|'device', index: number) {
        const arr = type === 'geo' ? this.geoRules() : this.deviceRules();
        arr.removeAt(index);
    }

    public geoRules() {
        return this.group.controls.geo_rules as FormArray;
    }

    public deviceRules() {
        return this.group.controls.device_rules as FormArray;
    }

    public value(): CrupdateLinkPayload {
        const payload = {...this.group.value};

        // merge device / country rules and remove empty rules
        payload.rules = payload.geo_rules
            .concat(payload.device_rules)
            .filter(rule => rule.key && rule.value);

        // delete geo and device rule fields
        delete payload.geo_rules; delete payload.device_rules;

        // split link type into type and type id values
        if (payload.type.indexOf(':') > -1) {
            payload.type_id = parseInt(payload.type.split(':')[1]);
            payload.type = payload.type.split(':')[0];
        }

        if (payload.multiple_urls) {
            payload.multiple_urls = payload.multiple_urls.split(/\n/g);
            // send only single url or multiple urls
            delete payload.long_url;
            delete payload.alias;
        } else {
            // make sure validation is not triggered with empty string
            delete payload.multiple_urls;
        }

        return payload;
    }

    private build() {
        const defaultType = this.settings.get('links.default_type', 'direct');
        this.group = this.fb.group({
            type: [defaultType],
            title: [''],
            long_url: [''],
            multiple_urls: [''],
            domain_id: [null],
            hash: [''],
            alias: [''],
            password: [''],
            disabled: [false],
            expires_at: [''],
            description: [''],
            tags: [[]],
            pixels: [[]],
            geo_rules: this.fb.array([
               this.newRuleGroup('geo')
            ]),
            device_rules: this.fb.array([
                this.newRuleGroup('device')
            ])
        });

        this.group.get('multiple_urls').valueChanges.subscribe(value => {
            if (value) {
                this.group.get('alias').disable();
            } else {
                this.group.get('alias').enable();
            }
        });
    }

    private newRuleGroup(type: 'geo'|'device') {
        const defaultKey = type === 'geo' ? 'us' : 'phone';
        return this.fb.group({key: [defaultKey], value: [''], type: [type]});
    }

    public patchValue(link?: Link) {
        if (link) {
            const value = {...link} as {[key: string]: any};
            // type=overlay, type_id=1 => type=overlay:1
            if (value.type_id) {
                value.type = `${link.type}:${link.type_id}`;
            }
            value.geo_rules = link.rules.filter(r => r.type === 'geo');
            value.device_rules = link.rules.filter(r => r.type === 'device');
            value.tags = value.tags.map(t => t.name);
            value.pixels = value.pixels.map(p => p.id);
            this.group.patchValue(value);
        }
    }

    public setErrors(messages?: LinkErrors) {
        this.errors$.next(messages || {});
    }
}
