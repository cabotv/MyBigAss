import {Component, ChangeDetectionStrategy} from '@angular/core';
import {Settings} from '@common/core/config/settings.service';

@Component({
    selector: 'footer',
    templateUrl: './footer.component.html',
    styleUrls: ['./footer.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class FooterComponent {
    constructor(public settings: Settings) {}

    public year() {
        return new Date().getFullYear();
    }
}
