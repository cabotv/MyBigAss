export interface HomepageContent {
    headerTitle: string;
    headerSubtitle: string;
    footerTitle: string;
    footerSubtitle: string;
    actions: {
        inputText: string;
        inputButton: string;
        cta1: string;
        cta2: string;
    };
    primaryFeatures: {
        title: string;
        subtitle: string;
        image: string;
    }[];
    secondaryFeatures: {
        title: string;
        subtitle: string;
        description: string;
        image: string;
    }[];
}
